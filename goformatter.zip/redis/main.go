package main

import (
	"bytes"
	"encoding/gob"
	"fmt"
	"github.com/go-redis/redis"
)

type TestObj struct {
	T int    `json:"T"`
	M string `json:"M"`
}

func main() {
	gob.Register(&TestObj{})
	client := redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "",
		DB:       0,
	})
	defer client.Close()
	b := new(bytes.Buffer)
	enc := gob.NewEncoder(b)
	if err := enc.Encode(&TestObj{1, "test"}); err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(client.Set("key", b.Bytes(), 0).Err())
}
