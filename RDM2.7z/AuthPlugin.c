#include <stdio.h>

typedef char* (*exec_func)(void *, char *);
typedef void (*free_func) (void *);
typedef void (*log_func)(void *, char *);
typedef int (*auth_func)(void *, char *, exec_func, free_func, log_func);

int auth(void *ctx, char *password, exec_func ef, free_func ff, log_func lf){
	char *out = ef(ctx, "AUTH 10086");
	if (out) {
		lf(ctx, out);
		ff(out);
	}
	out = ef(ctx, "PING");
	if (out) {
		lf(ctx, out);
		ff(out);
	}
    return strcmp(password, "111");
}